# nodejs-restapi-mongo
Example Project on how to build and develop REST API with NodeJS and MongoDB
