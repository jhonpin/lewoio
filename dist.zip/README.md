# mevn-stack-example
Example Project on how to develop and build MEVN with an example project
