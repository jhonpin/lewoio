<template>
    <div class="header">
        MEVN Stack Example
    </div>
</template>

<script>
    
    export default {
        name: 'Header',
        data() {
            return {
                tasks: []
            }
        }
    }
</script>